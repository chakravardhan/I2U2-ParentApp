package com.i2u2.parent.fragments;


public interface OnCallEventsController {

    void onSwitchAudio();

    void onUseHeadSet(boolean use);

}
